package com.gabo.petagram.db;

/**
 * Created by galael on 19/08/17.
 */

public final class ConstantesMascotaDB {
    public static final String DATABASE_NAME = "DB_MASCOTAS";
    public static final int DATABASE_VERSION = 1;

    public static final String TABLE_MASCOTA            = "mascota";
    public static final String TABLE_MASCOTA_ID         = "id";
    public static final String TABLE_MASCOTA_NOMBRE     = "nombre";
    public static final String TABLE_MASCOTA_FOTO       = "foto";

    public static final String TABLE_LIKES              = "mascota_likes";
    public static final String TABLE_LIKES_ID           = "id";
    public static final String TABLE_LIKES_ID_MASCOTA   = "id_mascota";
    public static final String TABLE_LIKES_NUMERO_LIKES = "numero_likes";
}
