package com.gabo.petagram.model;

import android.content.ContentValues;
import android.content.Context;

import com.gabo.petagram.R;
import com.gabo.petagram.db.ConstantesMascotaDB;
import com.gabo.petagram.db.MascotaDB;

import java.util.ArrayList;


/**
 * Created by galael on 19/08/17.
 */

public class ConstructorMascotas {

    private static final int LIKE = 1;
    private Context context;

    public ConstructorMascotas(Context context) {
        this.context = context;
    }

    public ArrayList<Mascota> getMascotas() {
        ArrayList<Mascota> aMascotas = new ArrayList<>();
        MascotaDB db = new MascotaDB(context);
        aMascotas = db.getMascotas();
        if (aMascotas.size() == 0)
            inicializarMascotas(db);
        return  db.getMascotas();
    }

    public void inicializarMascotas(MascotaDB mascotaDB) {

        ContentValues contentValues = new ContentValues();

        contentValues.put(ConstantesMascotaDB.TABLE_MASCOTA_NOMBRE, "Alita");
        contentValues.put(ConstantesMascotaDB.TABLE_MASCOTA_FOTO, R.drawable.img_alita);
        mascotaDB.insertMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(ConstantesMascotaDB.TABLE_MASCOTA_NOMBRE, "Conejito");
        contentValues.put(ConstantesMascotaDB.TABLE_MASCOTA_FOTO, R.drawable.img_conejito);
        mascotaDB.insertMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(ConstantesMascotaDB.TABLE_MASCOTA_NOMBRE, "Espanto");
        contentValues.put(ConstantesMascotaDB.TABLE_MASCOTA_FOTO, R.drawable.img_espanto);
        mascotaDB.insertMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(ConstantesMascotaDB.TABLE_MASCOTA_NOMBRE, "Lanudo");
        contentValues.put(ConstantesMascotaDB.TABLE_MASCOTA_FOTO, R.drawable.img_lanudo);
        mascotaDB.insertMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(ConstantesMascotaDB.TABLE_MASCOTA_NOMBRE, "Mike");
        contentValues.put(ConstantesMascotaDB.TABLE_MASCOTA_FOTO, R.drawable.img_mike);
        mascotaDB.insertMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(ConstantesMascotaDB.TABLE_MASCOTA_NOMBRE, "Mem");
        contentValues.put(ConstantesMascotaDB.TABLE_MASCOTA_FOTO, R.drawable.img_mem);
        mascotaDB.insertMascota(contentValues);
    }

    public void setLikeMascota(Mascota mascota){
        MascotaDB db = new MascotaDB(context);

        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantesMascotaDB.TABLE_LIKES_ID_MASCOTA, mascota.getId());
        contentValues.put(ConstantesMascotaDB.TABLE_LIKES_NUMERO_LIKES, LIKE);
        db.insertLike(contentValues);
    }

    public int getLikesMascota(Mascota mascota){
        MascotaDB db = new MascotaDB(context);
        return db.getLikes(mascota);
    }

}
