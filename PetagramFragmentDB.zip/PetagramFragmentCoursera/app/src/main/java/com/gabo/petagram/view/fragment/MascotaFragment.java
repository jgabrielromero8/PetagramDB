package com.gabo.petagram.view.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.gabo.petagram.R;
import com.gabo.petagram.adapter.MascotaAdapter;
import com.gabo.petagram.model.Mascota;
import com.gabo.petagram.presenter.IMascotaFragmentPresenter;
import com.gabo.petagram.presenter.MascotaFragmentPresenter;

import java.util.ArrayList;

/**
 * Created by galael on 13/08/17.
 */


public class MascotaFragment extends Fragment implements IMascotaFragment{

    RecyclerView rvMascotas;
    private IMascotaFragmentPresenter presenter;
    public static ArrayList<Mascota> mascotas;

    public MascotaFragment(){

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_mascota,container,false);

        rvMascotas = (RecyclerView) view.findViewById(R.id.rvMascotas);
        presenter = new MascotaFragmentPresenter(this, getContext());
        return view;


    }


    @Override
    public void crearLinearLayoutVertical() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rvMascotas.setLayoutManager(linearLayoutManager);
    }

    @Override
    public MascotaAdapter inicializarMascotaAdapter(ArrayList<Mascota> mascotas) {
        MascotaAdapter mAdapter = new MascotaAdapter(mascotas);
        return mAdapter;
    }

    @Override
    public void inicializarMascotaAdapterRV(MascotaAdapter adapter) {
        rvMascotas.setAdapter(adapter);
    }
}
