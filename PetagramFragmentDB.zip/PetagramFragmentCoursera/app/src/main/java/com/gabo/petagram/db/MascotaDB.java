package com.gabo.petagram.db;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.gabo.petagram.model.Mascota;

import java.util.ArrayList;

/**
 * Created by galael on 19/08/17.
 */

public class MascotaDB extends SQLiteOpenHelper {

    private Context context;

    public MascotaDB(Context context) {
        super(context, ConstantesMascotaDB.DATABASE_NAME, null, ConstantesMascotaDB.DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String queryCreateTableMascota = "CREATE TABLE " + ConstantesMascotaDB.TABLE_MASCOTA +
                "(" +
                        ConstantesMascotaDB.TABLE_MASCOTA_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        ConstantesMascotaDB.TABLE_MASCOTA_NOMBRE + " TEXT, " +
                        ConstantesMascotaDB.TABLE_MASCOTA_FOTO + " INTEGER" +
                ")";

        String queryCreateTableLikes = "CREATE TABLE " + ConstantesMascotaDB.TABLE_LIKES +
                "(" +
                        ConstantesMascotaDB.TABLE_LIKES_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        ConstantesMascotaDB.TABLE_LIKES_ID_MASCOTA + " INTEGER, " +
                        ConstantesMascotaDB.TABLE_LIKES_NUMERO_LIKES + " INTEGER, " +
                        "FOREIGN KEY (" + ConstantesMascotaDB.TABLE_LIKES_ID_MASCOTA + ") " +
                        "REFERENCES " + ConstantesMascotaDB.TABLE_MASCOTA + "(" + ConstantesMascotaDB.TABLE_MASCOTA_ID + ")" +
                ")";

        db.execSQL(queryCreateTableMascota);
        db.execSQL(queryCreateTableLikes);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXIST " + ConstantesMascotaDB.TABLE_MASCOTA);
        db.execSQL("DROP TABLE IF EXIST " + ConstantesMascotaDB.TABLE_LIKES);
        onCreate(db);
    }

    public ArrayList<Mascota> getMascotas() {
        ArrayList<Mascota> mascotas = new ArrayList<>();

        String query = "SELECT * FROM " + ConstantesMascotaDB.TABLE_MASCOTA;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor registros = db.rawQuery(query, null);

        while (registros.moveToNext()){
            Mascota mascotaActual = new Mascota();
            mascotaActual.setId(registros.getInt(0));
            mascotaActual.setNombre(registros.getString(1));
            mascotaActual.setFoto(registros.getInt(2));

            String queryLikes = "SELECT COUNT("+ConstantesMascotaDB.TABLE_LIKES_NUMERO_LIKES+") as likes " +
                    " FROM " + ConstantesMascotaDB.TABLE_LIKES +
                    " WHERE " + ConstantesMascotaDB.TABLE_LIKES_ID_MASCOTA + " = " + mascotaActual.getId();

            Cursor registrosLikes = db.rawQuery(queryLikes, null);
            if (registrosLikes.moveToNext()){
                mascotaActual.setMeGusta(registrosLikes.getInt(0));
            }else {
                mascotaActual.setMeGusta(0);
            }

            mascotas.add(mascotaActual);

        }

        db.close();

        return mascotas;
    }

    public int getLikes(Mascota mascota){
        int likes = 0;

        String query = "SELECT COUNT("+ConstantesMascotaDB.TABLE_LIKES_NUMERO_LIKES+")" +
                " FROM " + ConstantesMascotaDB.TABLE_LIKES +
                " WHERE " + ConstantesMascotaDB.TABLE_LIKES_ID_MASCOTA + " = "+ mascota.getId();

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor registros = db.rawQuery(query, null);

        if (registros.moveToNext()){
            likes = registros.getInt(0);
        }

        db.close();

        return likes;
    }

    public void insertMascota(ContentValues contentValues){
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(ConstantesMascotaDB.TABLE_MASCOTA,null, contentValues);
        db.close();
    }

    public void insertLike(ContentValues contentValues){
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(ConstantesMascotaDB.TABLE_LIKES, null, contentValues);
        db.close();
    }


}
