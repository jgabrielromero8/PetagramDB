package com.gabo.petagram;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import com.gabo.petagram.adapter.PageAdapter;
import com.gabo.petagram.view.fragment.MascotaFragment;
import com.gabo.petagram.view.fragment.PerfilMascotaFragment;
import java.util.ArrayList;

import static com.gabo.petagram.view.fragment.MascotaFragment.mascotas;

public class MainActivity extends AppCompatActivity {

    Toolbar actionBar;
    TabLayout tabLayout;
    ViewPager viewPager;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        actionBar = (Toolbar) findViewById(R.id.actionBar);
        setSupportActionBar(actionBar);



         viewPager = (ViewPager) findViewById(R.id.viewPager);
         tabLayout = (TabLayout) findViewById(R.id.tabLayout);

         setUpViewPager();

    }

    private void setUpViewPager() {
        viewPager.setAdapter(new PageAdapter(getSupportFragmentManager(), agregarFragments()));
        tabLayout.setupWithViewPager(viewPager);

        tabLayout.getTabAt(0).setIcon(R.drawable.ic_casa);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_mascota);
    }

    private ArrayList<Fragment> agregarFragments() {
        ArrayList<Fragment> fragments = new ArrayList<>();
        fragments.add(new MascotaFragment());
        fragments.add(new PerfilMascotaFragment());
        return fragments;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_fav:
                intent = new Intent(this,MascotaFavoritaActivity.class);
                //intent.putExtra("mascotas",MascotaFragment.mascotas);
                startActivity(intent);
                break;
            case R.id.moContacto:
                intent = new Intent(this,ContactoActivity.class);
                startActivity(intent);
                break;
            case R.id.moAcerca:
                intent = new Intent(this, AcercaDeActivity.class);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_favoritos,menu);
        getMenuInflater().inflate(R.menu.menu_opciones,menu);
        return super.onCreateOptionsMenu(menu);
    }
}
