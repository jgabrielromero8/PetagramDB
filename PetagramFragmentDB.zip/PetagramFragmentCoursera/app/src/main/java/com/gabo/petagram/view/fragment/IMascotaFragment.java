package com.gabo.petagram.view.fragment;

import com.gabo.petagram.adapter.MascotaAdapter;
import com.gabo.petagram.model.Mascota;

import java.util.ArrayList;

/**
 * Created by galael on 19/08/17.
 */

public interface IMascotaFragment {

    public void crearLinearLayoutVertical();

    public MascotaAdapter inicializarMascotaAdapter(ArrayList<Mascota> mascotas);

    public void inicializarMascotaAdapterRV(MascotaAdapter adapter);
}
