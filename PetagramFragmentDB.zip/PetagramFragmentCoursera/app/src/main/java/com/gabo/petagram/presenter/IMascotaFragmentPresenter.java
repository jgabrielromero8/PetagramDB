package com.gabo.petagram.presenter;

/**
 * Created by galael on 19/08/17.
 */

public interface IMascotaFragmentPresenter {

    public void getMascotas();

    public void mostrarMascotasRV();
}
