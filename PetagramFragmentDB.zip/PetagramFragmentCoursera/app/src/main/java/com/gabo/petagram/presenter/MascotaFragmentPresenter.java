package com.gabo.petagram.presenter;

import android.content.Context;

import com.gabo.petagram.model.ConstructorMascotas;
import com.gabo.petagram.model.Mascota;
import com.gabo.petagram.view.fragment.IMascotaFragment;

import java.util.ArrayList;

/**
 * Created by galael on 19/08/17.
 */

public class MascotaFragmentPresenter implements IMascotaFragmentPresenter {

    private IMascotaFragment iMascotaFragment;
    private Context context;
    private ConstructorMascotas constructorMascotas;
    private ArrayList<Mascota> mascotas;

    public MascotaFragmentPresenter(IMascotaFragment iMascotaFragment, Context context) {
        this.iMascotaFragment = iMascotaFragment;
        this.context = context;
        getMascotas();
    }

    @Override
    public void getMascotas() {
        constructorMascotas = new ConstructorMascotas(context);
        mascotas = constructorMascotas.getMascotas();
        mostrarMascotasRV();
    }

    @Override
    public void mostrarMascotasRV() {
        iMascotaFragment.inicializarMascotaAdapterRV(iMascotaFragment.inicializarMascotaAdapter(mascotas));
        iMascotaFragment.crearLinearLayoutVertical();
    }
}
