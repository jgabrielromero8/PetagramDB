package com.gabo.petagram.pojo;

/**
 * Created by galael on 13/08/17.
 */

public class ConfigEmail {
    public static final String EMAIL ="";
    public static final String PASSWORD ="";
}
